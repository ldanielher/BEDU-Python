import listas

def test_procesa():
	""" Batería de pruebas para procesa() """
	assert listas.procesa([1,2,3,4,5]) == [1,2,3,4,5]
	assert listas.procesa([1,1,1,1,1]) == [1]
	assert listas.procesa([1,1,2,3,4,4,5]) == [1,2,3,4,5]
	assert listas.procesa([7,2,8,1,0,4,5,5]) == [0,1,2,4,5,7,8]
	